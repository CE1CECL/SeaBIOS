For questions and general information about SeaBIOS, please subscribe
to the
[SeaBIOS mailing list](https://mail.coreboot.org/postorius/lists/seabios.seabios.org/). It
is necessary to subscribe to the list in order to send emails (to
combat spam).

A mailing list archive is available at:
<https://mail.coreboot.org/hyperkitty/list/seabios@seabios.org/>

Messages prior to January 2019 are archived at:
<http://www.seabios.org/pipermail/seabios/>

An unofficial archive is also available at:
<https://www.mail-archive.com/seabios@seabios.org/>
