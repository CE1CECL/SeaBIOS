// Place build generated version into a C variable
#include "autoversion.h"

char VERSION[] = BUILD_VERSION;
char BUILDINFO[] = BUILD_TOOLS;
